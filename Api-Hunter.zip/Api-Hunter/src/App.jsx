import Method from "./Axiox-Method/Method1";
import Fetch from "./Fetch-Method/Fetch";
 
function  App() {
  return(
    <>
    <Method/>
    <Fetch/>
    </>
  )
}


export default App